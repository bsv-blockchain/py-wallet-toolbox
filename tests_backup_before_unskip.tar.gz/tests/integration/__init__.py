"""CWIStyleWalletManager integration tests module."""
