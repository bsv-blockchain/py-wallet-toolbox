"""Tests for satoshi arithmetic utilities."""
