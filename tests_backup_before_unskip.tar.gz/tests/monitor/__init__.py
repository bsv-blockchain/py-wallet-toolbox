"""Monitor module tests."""
