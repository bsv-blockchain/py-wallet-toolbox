"""Universal Test Vectors tests for bsv_wallet_toolbox."""
